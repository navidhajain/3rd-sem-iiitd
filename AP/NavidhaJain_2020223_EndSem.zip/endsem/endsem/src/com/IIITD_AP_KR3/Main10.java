package com.IIITD_AP_KR3;

//Q10: Using "assert", test if the code is running as expected. The code was expected to implement (a+b)^2 formula.
//In case something went wrong in the formula, your code should print the message "The formula is wrong."

public class Main10 {
    public static void main(String[] args) {

        int a=8;
        int b=2;
        int c=a*a+a*b+b*b;
        assert c==(a+b)*(a+b):"formula is wrong";
//        System.out.println(c);

    }
}

