package com.IIITD_AP_KR3;

//Q6: Modify A6 such that it implements the Comparable Interface. And compare a with b in terms of i-value in the main function.

import java.util.Comparator;

public class Main6 {
    public static void main(String[] args) {
        A6 a=new A6(5);
        A6 b=new A6(7);
        int x=a.compareTo(b);
        if(x>0){
            System.out.println("a is greater");
        }else if(x<0){
            System.out.println("b is greater");
        }else{
            System.out.println("both are equal");
        }
    }
}

class A6 implements Comparable<A6>{
    int i;
    A6(int i){
        this.i=i;
    }

    @Override
    public int compareTo(A6 o) {
        return this.i-o.i;
    }
}

//class A6{
//    int i;
//    A6(int i){
//        this.i=i;
//    }
//}
//
//class tocompare implements Comparator<A6> {
//    @Override
//    public int compare(A6 a, A6 b) {
//        int temp = a.i - b.i;
//        if (temp > 0) {
//            return 1;
//        } else if (temp < 0) {
//            return -1;
//        } else {
//            return 0;
//        }
//    }
//}

//    @Override
//    public int compareTo(A6 o) {
//        return 0;
//    }


//class A6{
//    static A6 b;
//    static{
//        b=new A6(7);
//    }
//    int i;
//    A6(int i){
//        this.i=i;
//    }
//}