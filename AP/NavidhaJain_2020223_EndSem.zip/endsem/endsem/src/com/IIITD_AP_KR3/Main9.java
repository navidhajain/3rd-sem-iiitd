package com.IIITD_AP_KR3;

//Q9: Create the list of 5 complex numbers (class=cmplx2) and print them all using an iterator in the main function.

import java.util.ArrayList;
import java.util.Iterator;

public class Main9 {
    public static void main(String[] args) {
        ArrayList<cmplx2> arrlist= new ArrayList<>();
        cmplx2 c1=new cmplx2(1, 2);
        cmplx2 c2=new cmplx2(2, 3);
        cmplx2 c3=new cmplx2(3, 4);
        cmplx2 c4=new cmplx2(4, 5);
        cmplx2 c5=new cmplx2(5, 6);

        arrlist.add(c1);
        arrlist.add(c2);
        arrlist.add(c3);
        arrlist.add(c4);
        arrlist.add(c5);

        Iterator<cmplx2> iter=arrlist.iterator();
        while(iter.hasNext()){
            System.out.println(iter.next());
        }
//        System.out.println(iter.next());
    }
}

class cmplx2{
    double re;
    double im;
    cmplx2(double re, double im){
        this.re=re;
        this.im=im;
    }

    public String toString(){
        return re + "+" +im +"i";
    }
}