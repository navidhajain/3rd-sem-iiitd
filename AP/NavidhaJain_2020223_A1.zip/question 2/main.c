#include<stdio.h>
#include<unistd.h>

extern b(long a);

void a(){
    printf("\n function a\n");
    b(324);
    printf("back");
}   

int main(){
    a();
    return 0;
}
