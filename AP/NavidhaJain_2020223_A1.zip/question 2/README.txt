Name: Navidha Jain
Roll number: 2020223

We use the extern keyword. By using 'extern', we are telling the compiler that whatever follows it will be found at link time; 
don't reserve anything for it in the current pass since it will be encountered later.

'a' function is defined in the main function itself. It first prints out a message that it has arrived in 'a'.
It calls 'b' function and passes a long type argument to it.
'b' prints a message that we have arrived in the 'b' function.
In the b file, in the b funtion before ret we add 'push c' which pushes the address of c function
to the stack and makes it go to the 'c' function which prints a message to let us know it has arrived in the 'c' function.

We're able to do all this as we have linked all these 3 functions and files by first creating object files of the c files by using:
>>gcc -c c.c and gcc -c main.c.
we execute the assembly file using:
>>nasm -f elf64 -o b.o b.asm
and link all the three using the command:
>>gcc -no-pie -o output main.o b.o c.o