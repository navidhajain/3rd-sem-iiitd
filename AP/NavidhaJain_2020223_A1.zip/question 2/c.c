#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

void c(){
    printf("\nin c function\n");
    exit(0);
}