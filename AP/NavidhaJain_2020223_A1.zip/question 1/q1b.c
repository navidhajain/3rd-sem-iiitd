#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<fcntl.h> 
#include<string.h>
#include<stdlib.h>
#include<pthread.h>

float crosssec[]={0};
void readit(char sec);

void *tprocess(){
    readit('A');
}

void getscores(char* line, char sec, long scores[26][6], int index){
    char* t= strtok(line, ",");
    char *arr[8], *temp;
    float avg=0;
    for(int i=0; t!=NULL; i++){
        *(arr+i)=t;
        t=strtok(NULL, ",");
    }
    if(*arr[1]!=sec){
        return;
    }
    for(int i=2, k=0; i<8; i++, k++){
        scores[index][k]=strtol(arr[i], &temp, 10);
    }
}

void outavg(long scores[26][6], char sec){
    long sum;
    float avg;
    int num;
    
    for (int i = 0; i < 6; i++){
        sum=0;
        for (int j = 0; j < 26; j++){
            sum+=scores[j][i];
        }
        if(sec=='A'){
            num=9;
        }
        else if(sec=='B'){
            num=17;
        }
        else{
            char *c="Cannot process";
            write(1, c, strlen(c));
            // printf("Cannot process");
            return;
        }
        avg=(float)sum/num;
        crosssec[i]=crosssec[i]+avg;
        
        char buffer[200];
        sprintf(buffer, "Average of Assignment %d is %.3f\n", (i+1), avg);
        write(1, buffer, strlen(buffer));
    }    
}

void readit(char sec){
    int fd=open("student_record.csv", O_RDONLY | O_EXCL);
    char row[1000];
    if(fd<0){
        char *d="error";
        write(1, d, strlen(d));
        // printf("error");
        _exit(-1);
    }
    for (int i = 0; read(fd, &row[i++],1); i++){
        char bk='\n';
        if(row[i-1]==bk){
            break;
        }
    }
    long scores[26][6]={0};
    int i=0, m=0;
    while(read(fd, &row[i++], 1)){
        if(row[i-1]=='\n'){
            row[i-1]='\0'; 
            getscores(row, sec, scores, m);
            m++;
            i=0;
            row[0]='\0';     
        }
    }

    if(strcmp(row, "")!=0){
        row[i-1]='\0';
        getscores(row, sec, scores, m);
    }

    char buff2[100];
    sprintf(buff2, "\nFor Section %c: \n", sec);
    write(1, buff2, strlen(buff2));
    // printf("For section %c:\n", sec);
    outavg(scores, sec);
    close(fd);
}

int main(){
    pthread_t tid;
    
    pthread_create(&tid, NULL, tprocess, NULL);
    int x=pthread_join(tid, NULL);

    if(x==0){
        readit('B');
    }else{
        char *b="error";
        write(1, b, strlen(b));
        // printf("error");
    }
    char buff3[100];
    char *buff4="\n\ncross section average: \n";
    write(1, buff4, strlen(buff4));
    for(int i=0; i<6; i++){

        sprintf(buff3, "Assignment %d: %.3f\n", i+1, (crosssec[i]/2));
        write(1, buff3, strlen(buff3));
    }
}