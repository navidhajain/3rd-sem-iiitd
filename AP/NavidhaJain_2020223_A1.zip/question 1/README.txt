Name: Navidha Jain
Roll number: 2020223

PART A:
Every process on the system has a unique process ID number, 
known as the pid. This is simply an integer.
We call the fork system call and store the value in the pid variable created.
Fork system call is used for creating a new process, which is called child process, 
which runs concurrently with the process that makes the fork() call (parent process).
After a new child process is created, both processes will execute the next instruction 
following the fork() system call.
3 values are possible:
Negative Value: creation of a child process was unsuccessful. Here an error message will be printed in this case.
Zero: Returned to the newly created child process (sec A).
Positive value: Returned to parent or caller. The value contains process ID 
of newly created child process (sec B).

So when fork()==0 child process will be called and section A's task will be st in progress.
We open the csv file sing the open() system call in read only mode and store the return value
of the file descriptor in fd. "O_EXCL" prevents creation of a file if it already exists.
File descriptor is integer that uniquely identifies an open file of the process.

We read the file using the read system call.
From the file indicated by the file descriptor fd, the read() function reads the specified number of bytes 
of input into the memory area indicated by buffer to read data from that we pass as the second argument. 

We skip the first line which is the line for the headings.
We maintain a 2D array that contains all the scores of all the students and is used to compute the average of assignments later.
We pass line by line to a function that splits the line, converts the string into the required data type and 
store the value in the scores 2D array.

Then we simply call another function to compute and display the averages.
After this we close the file.

The waitpid() system call suspends execution of the current process until a child specified by pid 
argument has changed state.
If pid is greater than 0, waitpid() waits for termination of the specific child whose process ID is equal to pid.
If pid is equal to zero, waitpid() waits for termination of any child whose process group ID is equal to that of the caller.
If pid is -1, waitpid() waits for any child process to end.
If pid is less than -1, waitpid() waits for the termination of any child whose process group ID is equal to the absolute value of pid.
The status pointer points to a location where waitpid() can store a status value. This status value is zero if 
the child process explicitly returns zero status.
So when the value of status is 0 the entire process is repeated for the section B else error message will be printed.

PART B:
The POSIX thread or pthread libraries are a standards based thread API for C. It allows one to spawn a new concurrent process flow.
Threads require less overhead than "forking" or spawning a new process because the system does not initialize a new system 
virtual memory space and environment for the process.
All threads within a process share the same address space. A thread is spawned by defining a function and it's arguments which 
will be processed in the thread.

pthread_create is used to create a new thread.
It takes 4 arguments:
1. thread id
2. pointer to a structure that is used to define thread attributes, it is NULL in this program for default thread attributes.
3. pointer to a subroutine that is executed by the thread. The return type and parameter type of the subroutine must be of type void *. Here it is "tprocess".
4. pointer to void that contains the arguments to the function defined in the earlier argument. In this program it is NULL as we dont have any argument to pass through

pthread_join is used to wait for the termination of a thread.
It takes 2 arguments:
1. thread id
2. pointer to the location where the exit status of the thread mentioned in thread id is stored.

The rest of process as similiar to that in PART A.

To calculate the cross section average I have reused the data obtained from the thread and computed the average across the sections.

In the makefile to pause compilation we pass the required flags and store the output in a different file.