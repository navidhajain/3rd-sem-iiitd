
// import javax.fx.event.ChangeListener;
import java.util.Observable;

import javafx.animation.RotateTransition;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.util.Duration;

public class controller {
    RotateTransition rt;
    @FXML
    private Label display;

    @FXML
    private Button rotator;

    @FXML
    private Button rotor;

    @FXML
    void onRotatorClicked(MouseEvent event) {

        rotor.rotateProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {
                display.setText("The rotor has rotated " + String.valueOf(arg2.intValue()) + " degrees");
            }
        });
        rt = new RotateTransition(Duration.seconds(10), rotor);
        rt.setByAngle(360);
        rt.setCycleCount(1);
        rt.setAutoReverse(false);
        rt.play();
    }

    @FXML
    void onRotorClicked(MouseEvent event) {
        rt.stop();
    }

}
